﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Management.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace Management.Controllers
{
    public class ProductController : Controller
    {
        public AppDbContex db1;
        public IHostingEnvironment Environment { get; }
        public ProductController(AppDbContex con, IHostingEnvironment environment)
        {
            db1 = con;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var product = db1.products.ToList();
            return View(product);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Product product)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            product.Image = dbpath;
            db1.products.Add(product);
            db1.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            var d1 = db1.products.SingleOrDefault(e=>e.Id==id);
            db1.products.Remove(d1);
            db1.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Update(int id)
        {
            var u = db1.products.SingleOrDefault(e => e.Id == id);
            return View(u);
        }

        [HttpPost]
        public IActionResult Update(Product product)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            product.Image = dbpath;
            db1.products.Update(product);
            db1.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
