﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Management.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace Management.Controllers
{
    public class UserController : Controller
    {
        public AppDbContex db;
        public IHostingEnvironment Environment { get; }
        public UserController(AppDbContex context,IHostingEnvironment environment)
        {
            db = context;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var st = db.users.ToList();
            return View(st);
        }
        public IActionResult SignUp()
        { 
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(User users)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            users.Image = dbpath;
            db.users.Add(users);
            db.SaveChanges();
            /*return RedirectToAction("Index");*/
            return RedirectToAction("Login");
        }
       
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string email,string password)
        {
            /*var mail = db.users.SingleOrDefault(e => e.Email == email);
            var pass = db.users.SingleOrDefault(e => e.Password == password);*/
            if (db.users.Any(u => u.Email.ToLower() == email.ToLower()
                     && u.Password == password)==true)
            {
                ViewBag.m = email;
                return RedirectToAction("DashBoard");
            }
            else
            {
                var message = "Try Again";
                ViewBag.msg = message;
                return RedirectToAction("Login");
            }

            /* if (ModelState.IsValid)
             {
                 bool IsValidUser = db.users.Any(
                     u => u.Email.ToLower() == email.ToLower()
                     && user.Password == password);

                 if (IsValidUser)
                 {
                     *//*FormsAuthentication.SetAuthCookie(user.Email, false);*//*
                     return RedirectToAction("DashBoard");
                 }
                 else
                 {
                     var message = "Try Again";
                     ViewBag.msg = message;
                     return View();
                 }
             }
                 ModelState.AddModelError("", "invalid Username or Password");
                 return View();*/
        }
        public IActionResult DashBoard()
        {
            return View();
        }
        [HttpPost]
        public IActionResult DashBoard(string email)
        {
            var mail = db.users.SingleOrDefault(e=>e.Email==email);
            ViewBag.m = mail;
            return View();
        }
    }
}
